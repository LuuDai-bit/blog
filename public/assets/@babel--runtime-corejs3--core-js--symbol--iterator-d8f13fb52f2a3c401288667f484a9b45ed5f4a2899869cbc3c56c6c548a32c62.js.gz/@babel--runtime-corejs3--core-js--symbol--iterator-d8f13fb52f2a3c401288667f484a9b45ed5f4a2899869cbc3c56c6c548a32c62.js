// @babel/runtime-corejs3/core-js/symbol/iterator@7.29.2 downloaded from https://ga.jspm.io/npm:@babel/runtime-corejs3@7.29.2/core-js/symbol/iterator.js

import*as e from"core-js-pure/features/symbol/iterator";var t=e;try{`default`in e&&(t=e.default)}catch{}export{t as default};

