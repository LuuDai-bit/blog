// @babel/runtime-corejs3/core-js/instance/index-of@7.29.2 downloaded from https://ga.jspm.io/npm:@babel/runtime-corejs3@7.29.2/core-js/instance/index-of.js

import*as e from"core-js-pure/features/instance/index-of";var t=e;try{`default`in e&&(t=e.default)}catch{}export{t as default};

